This series of batch files and tasks were kluged together by Wobble to setup RyzenADJ to swap power profiles. 
While using RefreshRateSwitcher to swap refresh rates and a powershell command to set brigtness levels.

***IMPORTANT NOTE******************************

YOU ARE REQUIRED TO SET YOUR BIOS POWER PROFILE TO 54W OR YOU CAN'T INCREASE EDC TO 129.5A

************************************************

The Tasks and VBS script currently assume the folder is at C:\V3Adj they could be placed anywhere but would require modification.

V3 Adj task install.bat installs V3Startup.xml and V3_Batt-Ac.xml to task scheduler. 
They both call v3_PowerSwap.vbs which inturn calls V3_PowerSwap.bat this is simply to run the batch file with out having a window pop up.

V3Startup calls the script on startup to apply the appropriate profile. While V3_Batt-Ac is triggered on a power state change kernel event. 
The batch file actually does the power state check and acts accordingly.

My default values are all declared variables in V3_PowerSwap.bat and can be edited to your liking. 

V3 Adj task Uninstall.bat removes the above tasks.


Info.bat will call the current values with ryzenadj and wait for you to hit a key.


Thanks to FlyGoat for RyzenAdj and Sryze for RefreshRateSwitcher both can be acquired at the addresses below.

https://github.com/FlyGoat/RyzenAdj  
https://github.com/sryze/RefreshRateSwitcher